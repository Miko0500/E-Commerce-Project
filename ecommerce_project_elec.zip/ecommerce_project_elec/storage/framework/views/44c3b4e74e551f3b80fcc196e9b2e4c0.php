<!DOCTYPE html>
<html>
  <head> 
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <style type="text/css">

    table
    {
        border: 2px solid pink;
        text-align: center;
    }

    th
    {
        background-color: #dc3545;
        padding: 10px;
        font-size: 18px;
        font-weight: bold;
        color: white;
        border: 3px solid black;
        text-align: center;
    }

    .table_center
    {
        display: flex;
        justify-content: center;
        align-items: center;
        margin-top: 0px;
    }

    td
    {
        color: black;
        padding: 15px;
        border: 3px solid black;
        text-align: center;
        vertical-align: middle;
        background-color: lightpink;
        
    }

    .btn {
        display: flex;
        justify-content: center;
        align-items: center; /* Ensure the buttons are vertically centered */
        gap: 10px; /* Add space between the buttons */
    }

    .div_deg
    {
        display: flex;
        justify-content: center;
        align-items: center;
        margin-top: 10px;
    }

    h1 {
            color: #fff;
            text-align: center;
            margin-bottom: 30px;
        }

    </style>
  </head>
  <body>

    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- Sidebar Navigation end-->
      <div class="page-content">
        
        <div class="page-header">
        <h1 style="color: white; margin-bottom: 30px;">Customer Orders</h1>
          <div class="container-fluid">


        <div class="table_center">

          <table>

            <tr>

            <th>Customer Name</th>

            <th>Address</th>

            <th>Phone</th>

            <th>Product Title</th>

            <th>Price</th>

            <th>Image</th>

            <th>Status</th>

            <th>Change Status</th>

            <th>Print PDF</th>

            </tr>

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>

            <td><?php echo e($datas->name); ?></td>
            <td><?php echo e($datas->rec_address); ?></td>
            <td><?php echo e($datas->phone); ?></td>
            <td><?php echo e($datas->product->title); ?></td>
            <td><?php echo e($datas->product->price); ?></td>
            <td>

            <img width="100" height="100" src="products/<?php echo e($datas->product->image); ?>" alt="">

            </td>
            <td>

            <?php if($datas->status == 'in progress'): ?>

            <span class="btn btn-warning btn-sm" style="color: white;"><?php echo e($datas->status); ?></span>

            <?php elseif($datas->status == 'On The Way'): ?>

            <span class="btn btn-info btn-sm" style="color: white;"><?php echo e($datas->status); ?></span>

            <?php else: ?>

            <span class="btn btn-success btn-sm" style="color: white;"><?php echo e($datas->status); ?></span>

            <?php endif; ?>

            </td>

            <td>
                <a class="btn btn-info btn-sm btn-block" href="<?php echo e(url('on_the_way',$datas->id)); ?>">On The Way</a>

                <a class="btn btn-success btn-sm btn-block" href="<?php echo e(url('delivered',$datas->id)); ?>">Delivered</a>
            </td>

            <td>
                <a class="btn btn-secondary btn-sm" href="<?php echo e(url('print_pdf',$datas->id)); ?>">Print PDF</a>
            </td>
            

            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </table>

          </div>

          <div class="div_deg">

          <?php echo e($data->onEachSide(1)->links()); ?>


          </div>


          </div>
      </div>
    </div>
    <!-- JavaScript files-->
    <script src="<?php echo e(asset('/admincss/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/admincss/vendor/popper.js/umd/popper.min.js')); ?>"> </script>
    <script src="<?php echo e(asset('/admincss/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/admincss/vendor/jquery.cookie/jquery.cookie.js')); ?>"> </script>
    <script src="<?php echo e(asset('/admincss/vendor/chart.js/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/admincss/vendor/jquery-validation/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/admincss/js/charts-home.js')); ?>"></script>
    <script src="<?php echo e(asset('/admincss/js/front.js')); ?>"></script>
  </body>
</html><?php /**PATH C:\Users\mikob\ecommerce_project_elec\resources\views/admin/order.blade.php ENDPATH**/ ?>