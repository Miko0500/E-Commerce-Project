
  <!-- info section -->
  <section class="info_section  layout_padding2-top">
    <div class="social_container">
      <div class="social_box">
        <a href="">
          <i class="fa fa-facebook" aria-hidden="true"></i>
        </a>
        <a href="">
          <i class="fa fa-twitter" aria-hidden="true"></i>
        </a>
        <a href="">
          <i class="fa fa-instagram" aria-hidden="true"></i>
        </a>
        <a href="">
          <i class="fa fa-youtube" aria-hidden="true"></i>
        </a>
      </div>
    </div>
    
    <!-- footer section -->
    <footer class=" footer_section">
      <div class="foot_container">
        <p>
          &copy; <span id="displayYear"></span> Crochet
          <a href="https://html.design/">With Us</a>
        </p>
      </div>
    </footer>
    <!-- footer section -->

  </section>

  <!-- end info section -->

  <!-- end info section -->


  <script src="<?php echo e(asset('js/jquery-3.4.1.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js">
  </script>
  <script src="<?php echo e(asset('js/custom.js')); ?>"></script><?php /**PATH C:\Users\mikob\ecommerce_project_elec\resources\views/home/footer.blade.php ENDPATH**/ ?>