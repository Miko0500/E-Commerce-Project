<!DOCTYPE html>
<html>

<head>
  
<?php echo $__env->make('home.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style type="text/css">

    .div_center
    {
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 20px;
    }

    .detail-box
    {
        padding: 5px;
    }

</style>

</head>

<body>
  <div class="hero_area">
    <!-- header section strats -->
    <?php echo $__env->make('home.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end header section -->
 
  </div>



<!-- product details start -->


<section class="shop_section layout_padding">
    <div class="container">
      <div class="heading_container heading_center">
        <h2 style="color: #7b1717;">
          Product Details
        </h2>
      </div>
      <div class="row justify-content-center">

        

        <div class="col-md-8">
          <div class="box">
            
              <div class="div_center">
                <img width="300" src="/products/<?php echo e($data->image); ?>" alt="">
              </div>



              <div class="detail-box">
                <h6>Name : <?php echo e($data->title); ?></h6>
                <h6>Price : 
                  <span>$<?php echo e($data->price); ?></span>
                </h6>
              </div>

              <div class="detail-box">
                <h6>Category : <?php echo e($data->category); ?></h6>

                <h6>Available Quantity : 
                  <span><?php echo e($data->quantity); ?></span>
                </h6>
              </div>

              <div class="detail-box">
                

                
                  <p><?php echo e($data->description); ?></p>
                
              </div>
            

            

          </div>
        </div>

        


        
        
      </div>
      
    </div>
  </section>




<!-- product details end -->




   

  <!-- info section -->
<?php echo $__env->make('home.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\Users\mikob\ecommerce_project_elec\resources\views/home/product_details.blade.php ENDPATH**/ ?>