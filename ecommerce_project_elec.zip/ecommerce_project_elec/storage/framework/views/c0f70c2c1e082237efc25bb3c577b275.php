<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>


    <?php echo $__env->make('home.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <style type="text/css">

    .div_center
    {
        display: flex;
        justify-content: center;
        align-items: center;
        margin: 60px;
    }

    table
    {
        border: 2px solid black;
        text-align: center;
        width: 800px;
    }

    th
    {
        border: 2px solid black;
        text-align: center;
        color: white;
        font-size: 20px;
        font-weight: bold;
        background-color: #7b1717;
    }

    td
    {
        border: 2px solid black;
        padding: 10px;
    }

    .cart_value
    {
        text-align: center;
        margin-bottom: 70px;
        padding: 18px;
    }

    .order_deg
    {
        padding-right: 100px;
        margin-top: -50px;
    }
    
    label
    {
        display: inline-block;
        width: 150px;
    }

    .div_gap
    {
        padding: 20px;
    }

    .pagination li a {
        color: red; /* Change to your desired color */
        /* Add any additional styles here */
    }

    /* Style for active pagination link */
    .pagination li.active a {
        color: red; /* Change to your desired active color */
        /* Add any additional styles here */
    }

</style>
</head>
<body>
    
<div class="hero_area">
    <!-- header section strats -->
    <?php echo $__env->make('home.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="div_center">

    <table>

    <tr>

    <th>Product Name</th>
    <th>Product Price</th>
    <th>Delivery Status</th>
    <th>Image</th>

    </tr>

    <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>

    <td><?php echo e($orders->product->title); ?></td>
    <td><?php echo e($orders->product->price); ?></td>
    <td>
        
    <?php if($orders->status == 'in progress'): ?>

            <span class="btn btn-warning btn-sm" style="color: white;"><?php echo e($orders->status); ?></span>

            <?php elseif($orders->status == 'On The Way'): ?>

            <span class="btn btn-info btn-sm" style="color: white;"><?php echo e($orders->status); ?></span>

            <?php else: ?>

            <span class="btn btn-success btn-sm" style="color: white;"><?php echo e($orders->status); ?></span>

            <?php endif; ?>

    </td>
    <td>
    <img width="100" height="100" src="/products/<?php echo e($orders->product->image); ?>">
    </td>

    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>

    </div>
    </div>
<div class="div_center">

<?php echo e($order->onEachSide(1)->links()); ?>


</div>
</div>


  <!-- info section -->
  <section class="info_section  layout_padding2-top">
    <div class="social_container">
      <div class="social_box">
        <a href="">
          <i class="fa fa-facebook" aria-hidden="true"></i>
        </a>
        <a href="">
          <i class="fa fa-twitter" aria-hidden="true"></i>
        </a>
        <a href="">
          <i class="fa fa-instagram" aria-hidden="true"></i>
        </a>
        <a href="">
          <i class="fa fa-youtube" aria-hidden="true"></i>
        </a>
      </div>
    </div>
    
    <!-- footer section -->
    <footer class=" footer_section">
      <div class="container">
        <p>
          &copy; <span id="displayYear"></span> Crochet
          <a href="https://html.design/">With Us</a>
        </p>
      </div>
    </footer>
    <!-- footer section -->

  </section>

  <!-- end info section -->

  <?php echo $__env->yieldContent('content'); ?>

<script>
    (function() {
        history.pushState(null, null, location.href);
        window.onpopstate = function() {
            history.go(1);
        };
    })();
</script>

</body>
</html><?php /**PATH C:\Users\mikob\ecommerce_project_elec\resources\views/home/order.blade.php ENDPATH**/ ?>